export const taskTypes = [
  {
    stageName: "backlog",
    stageTitle: "Backlog",
    stage: 0,
  },
  {
    stageName: "todo",
    stageTitle: "Todo",
    stage: 1,
  },
  {
    stageName: "onGoing",
    stageTitle: "On Going",
    stage: 2,
  },
  {
    stageName: "done",
    stageTitle: "Done",
    stage: 3,
  },
];
