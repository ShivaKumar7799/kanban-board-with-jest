export const environment = {
  baseUrl: "https://64c8c694a1fe0128fbd62fc5.mockapi.io",
};
